# Executive Market Story — Synthetic Portfolio Dataset

The latest modeled quarter is 2026 Q3. Bengaluru leads year-over-year price momentum at roughly 8%, while Delhi NCR records the highest transaction volume and the largest available inventory pool. Mumbai remains the highest-priced market by a wide margin. Rental yields cluster around 3.5%–4.1% across the blended property mix, with Bengaluru at the upper end.

## Operating implications

1. **Momentum:** Bengaluru and Hyderabad show the strongest modeled price growth. Validate whether transaction depth and absorption support the trend before increasing exposure.
2. **Liquidity:** Delhi NCR leads transaction volume, suggesting the broadest modeled buyer pool, but its large inventory position should be tracked alongside days on market.
3. **Income:** Bengaluru produces the highest blended annualized rental yield in the latest quarter. Property-type mix can materially change this comparison.
4. **Pricing:** Mumbai remains a premium market, so absolute capital requirements are high even where percentage growth is more moderate.

These findings are generated from deterministic synthetic data and are intended only to demonstrate analytical storytelling.
