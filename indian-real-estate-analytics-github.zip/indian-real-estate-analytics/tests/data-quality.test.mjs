import assert from "node:assert/strict";
import fs from "node:fs";

const snapshot = JSON.parse(fs.readFileSync(new URL("../src/data.json", import.meta.url), "utf8"));
const rows = snapshot.queries.real_estate_market.rows;

assert.equal(rows.length, 352, "expected 8 cities × 4 property types × 11 quarters");
assert.equal(new Set(rows.map((row) => `${row.periodStart}|${row.city}|${row.propertyType}`)).size, rows.length, "composite keys must be unique");
assert.equal(new Set(rows.map((row) => row.city)).size, 8, "expected eight markets");
assert.equal(new Set(rows.map((row) => row.propertyType)).size, 4, "expected four property types");
for (const row of rows) {
  for (const field of ["avgPricePerSqFt", "avgMonthlyRentPerSqFt", "transactions", "inventoryUnits", "daysOnMarket", "priceIndex"]) assert.ok(Number.isFinite(row[field]) && row[field] >= 0, `${field} must be non-negative`);
  assert.ok(Math.abs(row.rentalYield - (row.avgMonthlyRentPerSqFt * 12 / row.avgPricePerSqFt)) < 0.00011, "rental yield must reconcile");
}
assert.equal(snapshot.status, "fixture");
console.log(`Validated ${rows.length} synthetic real-estate rows.`);
