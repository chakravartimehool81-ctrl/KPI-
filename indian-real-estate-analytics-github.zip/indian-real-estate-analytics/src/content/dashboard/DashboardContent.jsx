import React, { useEffect, useMemo, useRef, useState } from "react";
import { DataComponent, DataTable, EvidenceChart, MetricCard, Section, SortableItem, SortableRegion, useDataApp } from "../../data-app-public.jsx";
import { downloadCsvTemplate, parseRealEstateFile } from "./import-data.js";

const QUERY_ID = "real_estate_market";
const STORAGE_KEY = "india-real-estate-dashboard:imported-data:v1";
const rupees = new Intl.NumberFormat("en-IN", { style: "currency", currency: "INR", maximumFractionDigits: 0 });
const whole = new Intl.NumberFormat("en-IN", { maximumFractionDigits: 0 });
const oneDecimal = new Intl.NumberFormat("en-IN", { minimumFractionDigits: 1, maximumFractionDigits: 1 });
const percent = new Intl.NumberFormat("en-IN", { style: "percent", minimumFractionDigits: 1, maximumFractionDigits: 1 });
const sum = (rows, field) => rows.reduce((total, row) => total + (Number(row[field]) || 0), 0);
const weighted = (rows, field, weight = "transactions") => { const denominator = sum(rows, weight); return denominator > 0 ? rows.reduce((total, row) => total + Number(row[field] || 0) * Number(row[weight] || 0), 0) / denominator : null; };
const change = (current, prior) => current != null && prior > 0 ? current / prior - 1 : null;
const latestDate = (rows) => rows.reduce((latest, row) => row.periodStart > latest ? row.periodStart : latest, "");

function periodLabel(value) { const date = new Date(`${value}T00:00:00Z`); return `${date.getUTCFullYear()} Q${Math.floor(date.getUTCMonth() / 3) + 1}`; }
function fourQuartersEarlier(value) { const date = new Date(`${value}T00:00:00Z`); date.setUTCFullYear(date.getUTCFullYear() - 1); return date.toISOString().slice(0, 10); }
function summarize(rows) {
  const price = weighted(rows, "avgPricePerSqFt");
  const rent = weighted(rows, "avgMonthlyRentPerSqFt");
  return { price, rent, rentalYield: price > 0 && rent != null ? rent * 12 / price : null, transactions: sum(rows, "transactions"), inventoryUnits: sum(rows, "inventoryUnits"), daysOnMarket: weighted(rows, "daysOnMarket"), priceIndex: weighted(rows, "priceIndex") };
}
function groupRows(rows, field) {
  const groups = new Map();
  for (const row of rows) { const key = row[field]; if (!groups.has(key)) groups.set(key, []); groups.get(key).push(row); }
  return [...groups].map(([key, values]) => ({ [field]: key, ...summarize(values) }));
}
function filterRows(rows, filters, includeDate = true) {
  return rows.filter((row) => (!includeDate || ((!filters.start || row.periodStart >= filters.start) && (!filters.end || row.periodStart <= filters.end))) && (filters.city === "all" || row.city === filters.city) && (filters.propertyType === "all" || row.propertyType === filters.propertyType));
}
function readSavedImport() { try { const saved = JSON.parse(localStorage.getItem(STORAGE_KEY)); return Array.isArray(saved?.rows) && saved.rows.length ? saved : null; } catch { return null; } }

function Insight({ tone, eyebrow, title, body }) {
  return <article className="market-insight" data-tone={tone}><span className="insight-accent" aria-hidden="true" /><div><span className="insight-eyebrow">{eyebrow}</span><strong>{title}</strong><p>{body}</p></div></article>;
}
function DataImportPanel({ imported, onImport, onReset, error, busy }) {
  const inputRef = useRef(null);
  return <section className="import-panel" aria-labelledby="import-title"><div className="import-copy"><div className="import-heading-row"><h2 id="import-title">Analyze your own market data</h2><span className="data-status" data-active={Boolean(imported)}>{imported ? "Imported data active" : "Demo data active"}</span></div><p>Upload a CSV file to recalculate every KPI, chart, comparison, and market story inside the portable app.</p><p className="privacy-note">Your file remains on this computer and is stored only in this app's local browser profile.</p>{imported && <p className="import-summary"><strong>{imported.fileName}</strong> · {whole.format(imported.rows.length)} rows · imported {new Date(imported.importedAt).toLocaleString("en-IN")}</p>}{error && <p className="import-error" role="alert">{error}</p>}</div><div className="import-actions"><input ref={inputRef} className="file-input" type="file" accept=".csv,text/csv" onChange={onImport} /><button className="primary-action" type="button" disabled={busy} onClick={() => inputRef.current?.click()}>{busy ? "Reading file…" : imported ? "Replace data" : "Upload CSV"}</button><button type="button" onClick={downloadCsvTemplate}>Download template</button>{imported && <button className="text-action" type="button" onClick={onReset}>Restore demo data</button>}</div></section>;
}
function DashboardFilters({ bounds, values, cities, propertyTypes, onChange }) {
  return <div className="local-filters" role="group" aria-label="Real estate dashboard filters"><label>From<input type="date" min={bounds.start} max={values.end || bounds.end} value={values.start} onChange={(event) => onChange({ ...values, start: event.target.value })} /></label><label>To<input type="date" min={values.start || bounds.start} max={bounds.end} value={values.end} onChange={(event) => onChange({ ...values, end: event.target.value })} /></label><label>City<select value={values.city} onChange={(event) => onChange({ ...values, city: event.target.value })}><option value="all">All cities</option>{cities.map((value) => <option key={value}>{value}</option>)}</select></label><label>Property type<select value={values.propertyType} onChange={(event) => onChange({ ...values, propertyType: event.target.value })}><option value="all">All property types</option>{propertyTypes.map((value) => <option key={value}>{value}</option>)}</select></label><button type="button" className="reset-action" onClick={() => onChange({ start: bounds.start, end: bounds.end, city: "all", propertyType: "all" })}>Reset filters</button></div>;
}

export function DashboardContent() {
  const { queries, visible } = useDataApp();
  const sampleRows = queries[QUERY_ID]?.rows ?? [];
  const [imported, setImported] = useState(readSavedImport);
  const [importError, setImportError] = useState("");
  const [importBusy, setImportBusy] = useState(false);
  const activeRows = imported?.rows ?? sampleRows;
  const bounds = useMemo(() => { const dates = [...new Set(activeRows.map((row) => row.periodStart))].sort(); return { start: dates[0] ?? "", end: dates.at(-1) ?? "" }; }, [activeRows]);
  const [filters, setFilters] = useState({ start: "", end: "", city: "all", propertyType: "all" });
  useEffect(() => setFilters({ start: bounds.start, end: bounds.end, city: "all", propertyType: "all" }), [bounds.start, bounds.end, imported?.fileName]);
  const cities = useMemo(() => [...new Set(activeRows.map((row) => row.city))].sort(), [activeRows]);
  const propertyTypes = useMemo(() => [...new Set(activeRows.map((row) => row.propertyType))].sort(), [activeRows]);
  const scopedRows = useMemo(() => filterRows(activeRows, filters), [activeRows, filters]);
  const comparableRows = useMemo(() => filterRows(activeRows, filters, false), [activeRows, filters.city, filters.propertyType]);
  const latest = latestDate(scopedRows);
  const latestRows = useMemo(() => scopedRows.filter((row) => row.periodStart === latest), [scopedRows, latest]);
  const latestSummary = useMemo(() => summarize(latestRows), [latestRows]);
  const priorDate = latest ? fourQuartersEarlier(latest) : "";
  const priorRows = useMemo(() => comparableRows.filter((row) => row.periodStart === priorDate), [comparableRows, priorDate]);
  const priorSummary = useMemo(() => summarize(priorRows), [priorRows]);
  const priceGrowth = change(latestSummary.price, priorSummary.price);
  const transactionTotal = sum(scopedRows, "transactions");
  const metricRows = [{ ...latestSummary, priceGrowth, transactionTotal, latestPeriod: latest }];
  const trends = useMemo(() => groupRows(scopedRows, "periodStart").map((row) => ({ ...row, quarter: periodLabel(row.periodStart) })).sort((a, b) => a.periodStart.localeCompare(b.periodStart)), [scopedRows]);
  const cityRows = useMemo(() => [...new Set(activeRows.map((row) => row.city))].map((city) => { const currentRows = latestRows.filter((row) => row.city === city); if (!currentRows.length) return null; const current = summarize(currentRows); const cityPrior = summarize(activeRows.filter((row) => row.city === city && row.periodStart === priorDate && (filters.propertyType === "all" || row.propertyType === filters.propertyType))); return { city, ...current, priceGrowth: change(current.price, cityPrior.price) }; }).filter(Boolean).sort((a, b) => b.price - a.price), [activeRows, latestRows, priorDate, filters.propertyType]);
  const growthLeader = cityRows.toSorted((a, b) => (b.priceGrowth ?? -Infinity) - (a.priceGrowth ?? -Infinity))[0];
  const yieldLeader = cityRows.toSorted((a, b) => (b.rentalYield ?? -Infinity) - (a.rentalYield ?? -Infinity))[0];
  const liquidityLeader = cityRows.toSorted((a, b) => b.transactions - a.transactions)[0];
  const inventoryWatch = cityRows.toSorted((a, b) => b.inventoryUnits - a.inventoryUnits)[0];

  async function handleImport(event) {
    const file = event.target.files?.[0]; event.target.value = ""; if (!file) return;
    setImportError(""); setImportBusy(true);
    try { if (file.size > 15 * 1024 * 1024) throw new Error("The file is larger than 15 MB. Please upload a smaller file."); const rows = await parseRealEstateFile(await file.arrayBuffer(), file.name); const next = { rows, fileName: file.name, importedAt: new Date().toISOString() }; localStorage.setItem(STORAGE_KEY, JSON.stringify(next)); setImported(next); }
    catch (error) { setImportError(error instanceof Error ? error.message : "The file could not be imported."); }
    finally { setImportBusy(false); }
  }
  function resetImport() { localStorage.removeItem(STORAGE_KEY); setImported(null); setImportError(""); }

  const columns = [
    { field: "city", label: "Market", presentation: "identity" },
    { field: "price", label: "Price / sq ft", renderCell: (value) => value == null ? "—" : rupees.format(value) },
    { field: "priceGrowth", label: "YoY price", renderCell: (value) => value == null ? "—" : percent.format(value), deltaTone: "positive" },
    { field: "rentalYield", label: "Rental yield", renderCell: (value) => value == null ? "—" : percent.format(value) },
    { field: "transactions", label: "Transactions", renderCell: whole.format },
    { field: "inventoryUnits", label: "Inventory", renderCell: whole.format },
    { field: "daysOnMarket", label: "Days on market", renderCell: (value) => value == null ? "—" : oneDecimal.format(value) },
    { field: "priceIndex", label: "Price index", renderCell: (value) => value == null ? "—" : oneDecimal.format(value) },
  ];

  return <>
    <DataImportPanel imported={imported} onImport={handleImport} onReset={resetImport} error={importError} busy={importBusy} />
    <DashboardFilters bounds={bounds} values={filters} cities={cities} propertyTypes={propertyTypes} onChange={setFilters} />
    <div className="dashboard-intro"><div><p>Executive intelligence across pricing, rental returns, demand, inventory, and market momentum.</p><span>Latest selected quarter: {latest ? periodLabel(latest) : "No data"}</span></div><strong>{imported ? `${imported.fileName} · ${whole.format(activeRows.length)} imported rows` : "Synthetic portfolio data · not investment advice"}</strong></div>
    <SortableRegion id="real-estate:kpis" label="Real estate KPI cards" variant="canvas" columns={12} spacing="standard" authoredRevision={1} rows={[{ id: "market-outcomes", kind: "metrics", items: ["kpi-price", "kpi-growth", "kpi-yield"] }, { id: "market-velocity", kind: "metrics", items: ["kpi-transactions", "kpi-inventory", "kpi-days"] }]}>
      {visible("kpi-price") && <SortableItem id="kpi-price" label="Average price per sq ft" kind="metric" span={4} minSpan={2}><MetricCard id="kpi-price" title="Average price / sq ft" queryId={QUERY_ID} value={latestSummary.price == null ? "—" : rupees.format(latestSummary.price)} comparison={priceGrowth == null ? null : `${priceGrowth >= 0 ? "+" : ""}${percent.format(priceGrowth)} YoY`} displayRows={metricRows} sourceRows={latestRows} /></SortableItem>}
      {visible("kpi-growth") && <SortableItem id="kpi-growth" label="Year-over-year price growth" kind="metric" span={4} minSpan={2}><MetricCard id="kpi-growth" title="YoY price growth" queryId={QUERY_ID} value={priceGrowth == null ? "—" : percent.format(priceGrowth)} displayRows={metricRows} sourceRows={[...latestRows, ...priorRows]} /></SortableItem>}
      {visible("kpi-yield") && <SortableItem id="kpi-yield" label="Annual rental yield" kind="metric" span={4} minSpan={2}><MetricCard id="kpi-yield" title="Annual rental yield" queryId={QUERY_ID} value={latestSummary.rentalYield == null ? "—" : percent.format(latestSummary.rentalYield)} displayRows={metricRows} sourceRows={latestRows} /></SortableItem>}
      {visible("kpi-transactions") && <SortableItem id="kpi-transactions" label="Transactions in selected period" kind="metric" span={4} minSpan={2}><MetricCard id="kpi-transactions" title="Transactions in period" queryId={QUERY_ID} value={whole.format(transactionTotal)} displayRows={metricRows} sourceRows={scopedRows} /></SortableItem>}
      {visible("kpi-inventory") && <SortableItem id="kpi-inventory" label="Latest available inventory" kind="metric" span={4} minSpan={2}><MetricCard id="kpi-inventory" title="Latest inventory" queryId={QUERY_ID} value={whole.format(latestSummary.inventoryUnits)} displayRows={metricRows} sourceRows={latestRows} /></SortableItem>}
      {visible("kpi-days") && <SortableItem id="kpi-days" label="Days on market" kind="metric" span={4} minSpan={2}><MetricCard id="kpi-days" title="Days on market" queryId={QUERY_ID} value={latestSummary.daysOnMarket == null ? "—" : oneDecimal.format(latestSummary.daysOnMarket)} displayRows={metricRows} sourceRows={latestRows} /></SortableItem>}
    </SortableRegion>
    <Section id="market-momentum" title="Market momentum" columns={2} spacing="after-metrics">
      <EvidenceChart id="price-trend" queryId={QUERY_ID} title="Price trajectory" rows={trends} sourceRows={scopedRows} height={310} spec={{ type: "line", x: "periodStart", y: "price", showXAxisLabel: false, showYAxisLabel: true, yLabel: "INR / sq ft", startAtZero: false, colors: { price: "var(--chart-1)" } }} />
      <EvidenceChart id="transaction-trend" queryId={QUERY_ID} title="Quarterly transaction volume" rows={trends} sourceRows={scopedRows} height={310} spec={{ type: "bar", x: "periodStart", y: "transactions", showXAxisLabel: false, showYAxisLabel: false, startAtZero: true, colors: { transactions: "var(--chart-2)" } }} />
    </Section>
    <Section id="market-comparison" title="City comparison" columns={2}>
      <EvidenceChart id="city-price" queryId={QUERY_ID} title="Latest price by market" rows={cityRows} sourceRows={latestRows} height={340} spec={{ type: "horizontalBar", x: "city", y: "price", showValues: true, showXAxisLabel: true, xLabel: "INR / sq ft", showYAxisLabel: false, startAtZero: true, colors: { price: "var(--chart-1)" } }} />
      <EvidenceChart id="city-yield" queryId={QUERY_ID} title="Annual rental yield by market" rows={cityRows.toSorted((a, b) => b.rentalYield - a.rentalYield)} sourceRows={latestRows} height={340} spec={{ type: "horizontalBar", x: "city", y: "rentalYield", showValues: false, showXAxisLabel: true, xLabel: "Annual yield", showYAxisLabel: false, startAtZero: true, valueDecimals: 3, colors: { rentalYield: "var(--chart-3)" } }} />
    </Section>
    <Section id="market-stories" title="Executive market stories"><DataComponent variant="card" id="market-insights" title="Signals from the selected scope" queryId={QUERY_ID} kind="custom" sourceRows={latestRows} displayRows={cityRows}>{cityRows.length ? <div className="insight-grid" data-reviewed-rows><Insight tone="positive" eyebrow="Momentum" title={`${growthLeader?.city} leads price growth`} body={`${percent.format(growthLeader?.priceGrowth ?? 0)} year-over-year growth in the latest selected quarter. Validate demand depth before treating appreciation as durable.`} /><Insight tone="yield" eyebrow="Income" title={`${yieldLeader?.city} offers the highest yield`} body={`${percent.format(yieldLeader?.rentalYield ?? 0)} annualized synthetic rental yield, based on weighted rent and price. Compare property mix before allocating capital.`} /><Insight tone="neutral" eyebrow="Liquidity" title={`${liquidityLeader?.city} leads transactions`} body={`${whole.format(liquidityLeader?.transactions ?? 0)} transactions in the latest quarter, indicating the broadest modeled liquidity in this scope.`} /><Insight tone="watch" eyebrow="Supply watch" title={`${inventoryWatch?.city} carries most inventory`} body={`${whole.format(inventoryWatch?.inventoryUnits ?? 0)} modeled units available at quarter end. Monitor absorption and days on market for pressure on pricing.`} /></div> : <p className="empty-state">No rows match the selected filters. Reset the filters or choose a wider date range.</p>}</DataComponent></Section>
    <Section id="market-detail" title="Market scorecard"><DataComponent variant="card" id="market-scorecard" title={`${latest ? periodLabel(latest) : "Latest quarter"} market comparison`} queryId={QUERY_ID} kind="table" sourceRows={latestRows} displayRows={cityRows}><DataTable columns={columns} rows={cityRows} searchable rowKey="city" caption="Indian real estate market scorecard" /></DataComponent></Section>
  </>;
}
