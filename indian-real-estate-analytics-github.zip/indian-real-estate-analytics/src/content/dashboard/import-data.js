export const REQUIRED_FIELDS = ["periodStart", "quarter", "city", "region", "propertyType", "avgPricePerSqFt", "avgMonthlyRentPerSqFt", "transactions", "inventoryUnits", "daysOnMarket"];
const HEADER_ALIASES = {
  periodStart:["periodstart","date","quarterstart","reportingdate"], quarter:["quarter","period"], city:["city","market"], region:["region","zone"], propertyType:["propertytype","type","segment"],
  avgPricePerSqFt:["avgpricepersqft","pricepersqft","pricepsf"], avgMonthlyRentPerSqFt:["avgmonthlyrentpersqft","rentpersqft","rentpsf"], transactions:["transactions","transactionvolume","sales"], inventoryUnits:["inventoryunits","inventory","availableunits"], daysOnMarket:["daysonmarket","dom"]
};
const compact = (value) => String(value ?? "").trim().toLowerCase().replace(/[^a-z0-9]/g, "");
const parseNumber = (value) => { if (typeof value === "number") return Number.isFinite(value) ? value : null; const parsed = Number(String(value ?? "").replace(/[^0-9.+-]/g, "")); return Number.isFinite(parsed) ? parsed : null; };
function parseDate(value) { if (value instanceof Date && Number.isFinite(value.getTime())) return value.toISOString().slice(0,10); if (typeof value === "number") return new Date(Date.UTC(1899,11,30) + value * 86400000).toISOString().slice(0,10); const text = String(value ?? "").trim(); const parsed = Date.parse(text); return Number.isFinite(parsed) ? new Date(parsed).toISOString().slice(0,10) : null; }
function normalize(rawRows) {
  const rows = rawRows.filter((row) => Object.values(row).some((value) => String(value ?? "").trim() !== ""));
  if (!rows.length) throw new Error("The selected file does not contain any data rows.");
  const available = new Map(Object.keys(rows[0]).map((key) => [compact(key), key]));
  const mapping = Object.fromEntries(REQUIRED_FIELDS.map((field) => [field, HEADER_ALIASES[field].map(compact).find((alias) => available.has(alias)) ? available.get(HEADER_ALIASES[field].map(compact).find((alias) => available.has(alias))) : null]));
  const missing = REQUIRED_FIELDS.filter((field) => !mapping[field]);
  if (missing.length) throw new Error(`Missing required columns: ${missing.join(", ")}. Download the template to see the expected layout.`);
  const normalized = rows.map((row,index) => {
    const periodStart = parseDate(row[mapping.periodStart]); const quarter = String(row[mapping.quarter] ?? "").trim(); const city = String(row[mapping.city] ?? "").trim(); const region = String(row[mapping.region] ?? "").trim(); const propertyType = String(row[mapping.propertyType] ?? "").trim();
    const numeric = Object.fromEntries(REQUIRED_FIELDS.slice(5).map((field) => [field, parseNumber(row[mapping[field]])]));
    if (!periodStart || !/^\d{4}-\d{2}-\d{2}$/.test(periodStart)) throw new Error(`Row ${index + 2}: periodStart is invalid.`);
    if (!quarter || !city || !region || !propertyType) throw new Error(`Row ${index + 2}: quarter, city, region, and propertyType are required.`);
    const invalid = Object.entries(numeric).find(([,value]) => value == null || value < 0); if (invalid) throw new Error(`Row ${index + 2}: ${invalid[0]} must be a non-negative number.`);
    const rentalYield = numeric.avgPricePerSqFt > 0 ? numeric.avgMonthlyRentPerSqFt * 12 / numeric.avgPricePerSqFt : 0;
    return { periodStart, quarter, city, region, propertyType, ...numeric, rentalYield, priceIndex: parseNumber(row.priceIndex ?? row["Price Index"]) ?? 100 };
  });
  const keys = normalized.map((row) => `${row.periodStart}|${row.city}|${row.propertyType}`); if (new Set(keys).size !== keys.length) throw new Error("Duplicate periodStart + city + propertyType rows were found.");
  return normalized.sort((a,b) => a.periodStart.localeCompare(b.periodStart) || a.city.localeCompare(b.city) || a.propertyType.localeCompare(b.propertyType));
}
function parseCsv(text) { const table=[]; let row=[],value="",quoted=false; for(let i=0;i<=text.length;i+=1){const ch=text[i]??"\n"; if(quoted){if(ch==='"'&&text[i+1]==='"'){value+='"';i+=1;}else if(ch==='"')quoted=false;else value+=ch;}else if(ch==='"')quoted=true;else if(ch===","){row.push(value);value="";}else if(ch==="\n"){row.push(value.replace(/\r$/,""));if(row.some((cell)=>cell!==""))table.push(row);row=[];value="";}else value+=ch;} const headers=table.shift()??[]; return table.map((cells)=>Object.fromEntries(headers.map((header,index)=>[header,cells[index]??""]))); }
export async function parseRealEstateFile(buffer,fileName="data.csv") { if(!fileName.toLowerCase().endsWith(".csv")) throw new Error("Please upload a CSV file. Use Download template for the required columns."); return normalize(parseCsv(new TextDecoder("utf-8").decode(buffer).replace(/^\uFEFF/,""))); }
export function downloadCsvTemplate() { const content=[REQUIRED_FIELDS.join(","),"2026-07-01,2026-Q3,Mumbai,West,Apartment,32000,115,3200,12000,65","2026-07-01,2026-Q3,Bengaluru,South,Apartment,15000,55,3600,12800,58"].join("\r\n"); const url=URL.createObjectURL(new Blob([content],{type:"text/csv;charset=utf-8"})); const link=document.createElement("a"); link.href=url; link.download="india-real-estate-template.csv"; link.click(); URL.revokeObjectURL(url); }
