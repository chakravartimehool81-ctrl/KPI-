# India Real Estate Market Intelligence

An interactive portfolio dashboard for exploring pricing, rental yields, transaction activity, inventory, and market momentum across major Indian real estate markets.

## Highlights

- Executive KPIs for price per square foot, year-over-year growth, rental yield, transactions, inventory, and days on market.
- Quarterly pricing and transaction trends from 2024 Q1 through 2026 Q3.
- City comparisons across Mumbai, Delhi NCR, Bengaluru, Hyderabad, Pune, Chennai, Kolkata, and Ahmedabad.
- Filters for date range, city, and property type.
- CSV upload inside the dashboard, with validation and local-only persistence.
- INR formatting throughout.
- Responsive layout, source inspection, chart export, theme switching, and editable dashboard layout.

## Important data note

The included dataset is deterministic synthetic portfolio data. It is not sourced from a registry, broker, property portal, or live market feed and must not be used for investment, lending, or valuation decisions.

## Run locally

Use a static HTTP server to serve `dist` after building. For development with the copied runtime:

```powershell
node "<data-plugin-root>/scripts/data-app.mjs" build --project-dir . --separate-data
python -m http.server 4175 --directory dist
```

Open `http://127.0.0.1:4175/?view=1&tab=dashboard`.

## Use external data

Select **Download template** in the dashboard, populate the CSV, then choose **Upload CSV**. Required columns are:

`periodStart, quarter, city, region, propertyType, avgPricePerSqFt, avgMonthlyRentPerSqFt, transactions, inventoryUnits, daysOnMarket`

The dashboard recomputes all KPIs and visuals in the browser. Uploaded rows remain local to that app profile.

## Repository structure

- `src/content/dashboard/` — authored dashboard and import logic
- `src/data.json` — reviewed synthetic dataset and provenance
- `data/india_real_estate_market.csv` — inspectable source data
- `tests/data-quality.test.mjs` — deterministic data checks
- `MARKET_INSIGHTS.md` — executive narrative based on the included demo dataset
- `dist/` — built dashboard

## License

MIT License. See `LICENSE`.
